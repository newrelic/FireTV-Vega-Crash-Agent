<a href="https://opensource.newrelic.com/oss-category/#new-relic-experimental"><picture><source media="(prefers-color-scheme: dark)" srcset="https://github.com/newrelic/opensource-website/raw/main/src/images/categories/dark/Experimental.png"><source media="(prefers-color-scheme: light)" srcset="https://github.com/newrelic/opensource-website/raw/main/src/images/categories/Experimental.png"><img alt="New Relic Open Source experimental project banner." src="https://github.com/newrelic/opensource-website/raw/main/src/images/categories/Experimental.png"></picture></a>

# New Relic Kepler Crash Turbo Module

It's a Kepler Turbo Module designed to capture native crashes on Kepler applications and report them to New Relic.

## Build & Install

Install dependencies:

```
$ npm install
```

Then build:

```
$ kepler build -b Debug -b Release
```

This will generate Debug and Release builds for all supported architectures. If you only want ther Release builds, just run `kepler build` without options.

Now generate the package:

```
$ npm pack
```

This will generate a file named `amzn-newrelickeplercrash-X.Y.Z.tgz`.

Move it to your app folder, and from there run:

```
$ npm install --save amzn-newrelickeplercrash-X.Y.Z.tgz
```

Now your app contains the Turbo Module and is ready to capture crashes, but it's still not able to report these crashes to New Relic. To do it, you need to install an [external tool](https://github.com/newrelic-experimental/newrelic-kepler-crash-sender). Please follow the installation instructions before proceding.

After completing all the steps, you can build and run your Kepler app normally.

## Setup

In the same place where you started the [New Relic Kepler Agent](https://github.com/newrelic-experimental/newrelic-kepler-agent?tab=readme-ov-file#setup), import this turbo module:

``` javascript
import { NrKeplerCrash } from '@amzn/nrkeplercrash';
```

And, after the call to `startAgent`, register the crash handler:

```javascript
NrKeplerCrash.registerHandler("<ACCOUNT ID>", "<API KEY>", "<US or EU>");
```

## Testing

The New Relic Kepler Crash turbo module provides a method to force a crash. You can call it to check that it can actually track crashes and report data to New Relic. Just call this method:

```javascript
NrKeplerCrash.crashNow();
```

## Support

For general help and support, please contact New Relic Account Team.

## Privacy

At New Relic we take your privacy and the security of your information seriously, and are committed to protecting your information. We must emphasize the importance of not sharing personal data in public forums, and ask all users to scrub logs and diagnostic information for sensitive information, whether personal, proprietary, or otherwise.

We define “Personal Data” as any information relating to an identified or identifiable individual, including, for example, your name, phone number, post code or zip code, Device ID, IP address, and email address.

For more information, review New Relic’s General Data Privacy Notice.

## License.

FireTV Vega Agent is licensed under the [New Relic Pre-release policy](https://docs.newrelic.com/docs/licenses/license-information/referenced-policies/new-relic-pre-release-policy/).

**Beta Release Notice:**
- This is a beta release suitable for testing and evaluation
- APIs may change in future versions based on feedback
- Please report issues and provide feedback via GitHub issues
- Contributions and pull requests are welcome
