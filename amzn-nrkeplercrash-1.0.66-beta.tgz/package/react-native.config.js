module.exports = {
    dependency: {
        platforms: {
            kepler: {
                "autolink": {
                    "NrKeplerCrash": {
                        "libraryName": "libNrKeplerCrash.so",
                        "linkDynamic": true,
                        "provider": "application",
                        "components": [],
                        "turbomodules": [
                            "NrKeplerCrash"
                        ]
                    }
                }
            },
        },
    },
};